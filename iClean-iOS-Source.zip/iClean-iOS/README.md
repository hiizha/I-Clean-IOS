# iClean for iOS

A lightweight SwiftUI storage helper for iOS 16+.

## What it can do
- Show an approximate device storage overview using public FileManager volume values.
- Measure and remove temporary/cache files created inside iClean's own sandbox.
- Provide shortcuts to Photos and iOS settings for user-reviewed cleanup.

## Important iOS limitation
Third-party iOS apps cannot directly inspect or delete another app's cache, clear iOS System Data, or remove system files. iClean does not use jailbreaks, private APIs, or destructive cleanup tricks.

## Build with GitHub Actions
1. Create a GitHub repository and upload the contents of this folder.
2. Ensure `.github/workflows/build.yml` is included.
3. Open **Actions** > **Build iClean IPA** > **Run workflow**.
4. Download the `iClean-unsigned-IPA` artifact.
5. Import the IPA into SideStore and sign/install it using your pairing setup.

Bundle ID: `com.tesa.iclean`
Minimum iOS: 16.0
