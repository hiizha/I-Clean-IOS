# iClean for iOS

SwiftUI storage helper for iOS 16+.

## Features
- Approximate device storage overview.
- Measure and clear temporary/cache files inside iClean's own sandbox.
- Safe manual-cleanup guidance for Photos, Safari, and iPhone Storage.
- System Light/Dark appearance support.

## iOS restrictions
iOS third-party apps cannot directly inspect or delete other apps' caches, clear iOS System Data, or remove system files. iClean does not use jailbreaks or private APIs.

## GitHub Actions build
1. Extract/upload the contents of this ZIP into the repository (the `.github` and `iClean` folders must be included).
2. Open Actions → Build iClean IPA → Run workflow.
3. Download `iClean-unsigned-IPA`.
4. Import the unsigned IPA into SideStore and sign it.

Bundle ID: `com.tesa.iclean`
Minimum iOS: 16.0

The workflow locates `iCleanApp.swift` automatically and generates the XcodeGen spec beside the source folder. This avoids the previous nested-folder `project.yml` path error.


## Build fix
The source has been corrected to use a real newline between `import SwiftUI` and `import UIKit`. The ZIP workflow also normalizes this formatting before compiling.
