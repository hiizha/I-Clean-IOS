import SwiftUI\nimport UIKit

struct ContentView: View {
    @State private var snapshot = StorageManager.snapshot()
    @State private var cacheSize = StorageManager.cacheBytes()
    @State private var showConfirm = false
    @State private var showResult = false
    @State private var resultText = ""
    @State private var isCleaning = false\n    @State private var showGuide = false\n    @State private var guideTitle = ""\n    @State private var guideMessage = ""

    private let teal = Color(red: 0.08, green: 0.68, blue: 0.62)

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    header
                    storageCard
                    cleanCard
                    toolsSection
                    safetyNote
                }
                .padding(.horizontal, 18)
                .padding(.top, 12)
                .padding(.bottom, 28)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationBarHidden(true)
            .confirmationDialog("Bersihkan cache iClean?", isPresented: $showConfirm, titleVisibility: .visible) {
                Button("Bersihkan Sekarang", role: .destructive) { cleanCache() }
                Button("Batal", role: .cancel) { }
            } message: {
                Text("Hanya file sementara milik iClean yang akan dihapus. Foto, dokumen, dan data aplikasi lain tidak disentuh.")
            }
            .alert("Selesai", isPresented: $showResult) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(resultText)
            }
            .alert(guideTitle, isPresented: $showGuide) {
                Button("Mengerti", role: .cancel) { }
            } message: {
                Text(guideMessage)
            }
            .onAppear(perform: refresh)
        }
        .tint(teal)
    }

    private var header: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 15).fill(teal).frame(width: 48, height: 48)
                Image(systemName: "sparkles").font(.system(size: 23, weight: .semibold)).foregroundStyle(.white)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text("iClean").font(.system(size: 27, weight: .bold, design: .rounded))
                Text("Penyimpanan lebih rapi, iPhone lebih lega").font(.system(size: 12)).foregroundStyle(.secondary)
            }
            Spacer()
            Button(action: refresh) {
                Image(systemName: "arrow.clockwise")
                    .font(.system(size: 16, weight: .semibold))
                    .padding(11)
                    .background(Color(uiColor: .secondarySystemGroupedBackground), in: Circle())
            }
            .accessibilityLabel("Perbarui")
        }
    }

    private var storageCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Penyimpanan iPhone").font(.headline)
                Spacer()
                Text("Perkiraan").font(.caption2).foregroundStyle(.secondary)
            }
            HStack(alignment: .firstTextBaseline, spacing: 5) {
                Text(formatGB(snapshot.used)).font(.system(size: 34, weight: .bold, design: .rounded))
                Text("digunakan").font(.subheadline).foregroundStyle(.secondary)
                Spacer()
                Text("dari \(formatGB(snapshot.total))").font(.subheadline).foregroundStyle(.secondary)
            }
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color(uiColor: .tertiarySystemFill))
                    Capsule().fill(teal).frame(width: max(5, geo.size.width * snapshot.usedFraction))
                }
            }
            .frame(height: 10)
            HStack {
                Label("Terpakai", systemImage: "circle.fill").foregroundStyle(teal)
                Spacer()
                Text("\(formatGB(snapshot.available)) tersedia").foregroundStyle(.secondary)
            }
            .font(.caption)
        }
        .padding(18)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22))
    }

    private var cleanCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("Pembersihan aman", systemImage: "shield.lefthalf.filled")
                    .font(.headline)
                Spacer()
                Text("AMAN").font(.system(size: 10, weight: .bold)).foregroundStyle(teal)
                    .padding(.horizontal, 9).padding(.vertical, 5)
                    .background(teal.opacity(0.12), in: Capsule())
            }
            Text("File sementara milik iClean").font(.subheadline).foregroundStyle(.secondary)
            HStack(alignment: .firstTextBaseline, spacing: 5) {
                Text(formatBytes(cacheSize)).font(.system(size: 29, weight: .bold, design: .rounded))
                Text("dapat dibersihkan").font(.caption).foregroundStyle(.secondary)
            }
            Button { showConfirm = true } label: {
                HStack {
                    if isCleaning { ProgressView().tint(.white) }
                    Text(isCleaning ? "Membersihkan..." : "Bersihkan cache")
                    Spacer()
                    Image(systemName: "arrow.right")
                }
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white)
                .padding(.horizontal, 16)
                .padding(.vertical, 15)
                .background(teal, in: RoundedRectangle(cornerRadius: 15))
            }
            .disabled(isCleaning || cacheSize == 0)
            Text("Membersihkan cache aplikasi iClean sendiri. Tidak menghapus data aplikasi lain.")
                .font(.caption2).foregroundStyle(.secondary)
        }
        .padding(18)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22))
    }

    private var toolsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Pembersihan iPhone").font(.headline).padding(.bottom, 2)
            toolRow(icon: "photo.on.rectangle.angled", title: "Foto & video besar", subtitle: "Tinjau dan hapus manual di Foto", action: openPhotos)
            toolRow(icon: "safari", title: "Data Safari", subtitle: "Kelola riwayat dan data situs", action: openSafariSettings)
            toolRow(icon: "externaldrive", title: "Penyimpanan aplikasi", subtitle: "Periksa aplikasi yang paling besar", action: openStorageSettings)
        }
    }

    private func toolRow(icon: String, title: String, subtitle: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 13) {
                Image(systemName: icon).font(.system(size: 19, weight: .medium)).foregroundStyle(teal)
                    .frame(width: 42, height: 42)
                    .background(teal.opacity(0.11), in: RoundedRectangle(cornerRadius: 12))
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                    Text(subtitle).font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
            }
            .padding(13)
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 17))
        }
        .buttonStyle(.plain)
    }

    private var safetyNote: some View {
        HStack(alignment: .top, spacing: 9) {
            Image(systemName: "info.circle.fill").foregroundStyle(teal)
            Text("iOS melindungi data aplikasi lain. iClean tidak memakai jailbreak atau akses tersembunyi, sehingga tidak dapat menghapus cache sistem maupun cache aplikasi lain secara langsung.")
                .font(.caption2).foregroundStyle(.secondary)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(teal.opacity(0.08), in: RoundedRectangle(cornerRadius: 15))
    }

    private func refresh() {
        snapshot = StorageManager.snapshot()
        cacheSize = StorageManager.cacheBytes()
    }

    private func cleanCache() {
        isCleaning = true
        do {
            let removed = try StorageManager.cleanOwnCache()
            resultText = "Berhasil menghapus sekitar \(formatBytes(removed)) file sementara milik iClean."
        } catch {
            resultText = "Sebagian file tidak dapat dihapus: \(error.localizedDescription)"
        }
        refresh()
        isCleaning = false
        showResult = true
    }

    private func formatGB(_ bytes: Int64) -> String {
        guard bytes > 0 else { return "— GB" }
        return String(format: "%.1f GB", Double(bytes) / 1_000_000_000)
    }

    private func formatBytes(_ bytes: Int64) -> String {
        let formatter = ByteCountFormatter()
        formatter.countStyle = .file
        return formatter.string(fromByteCount: bytes)
    }

    private func openStorageSettings() {
        guideTitle = "Penyimpanan iPhone"
        guideMessage = "Buka Pengaturan > Umum > Penyimpanan iPhone. Periksa ukuran aplikasi, lalu gunakan Hapus App atau Keluarkan App sesuai kebutuhan. Keluarkan App mempertahankan dokumen dan data."
        showGuide = true
    }

    private func openSafariSettings() {
        guideTitle = "Data Safari"
        guideMessage = "Buka Pengaturan > Apps > Safari > Hapus Riwayat dan Data Situs Web. Tindakan ini dapat mengeluarkan Anda dari beberapa situs dan menghapus data penelusuran."
        showGuide = true
    }

    private func openPhotos() {
        guideTitle = "Foto & video besar"
        guideMessage = "Buka Foto > Album > Video atau Tangkapan Layar. Tinjau file sebelum menghapusnya. Periksa juga album Baru Dihapus jika ingin mengosongkan ruang sepenuhnya."
        showGuide = true
    }
}
