import Foundation

struct StorageSnapshot {
    let total: Int64
    let available: Int64
    var used: Int64 { max(0, total - available) }
    var usedFraction: Double {
        guard total > 0 else { return 0 }
        return min(1, max(0, Double(used) / Double(total)))
    }
}

enum StorageManager {
    static func snapshot() -> StorageSnapshot {
        let values = try? URL(fileURLWithPath: NSHomeDirectory())
            .resourceValues(forKeys: [.volumeTotalCapacityKey, .volumeAvailableCapacityForImportantUsageKey])
        let total = Int64(values?.volumeTotalCapacity ?? 0)
        let available = Int64(values?.volumeAvailableCapacityForImportantUsage ?? 0)
        return StorageSnapshot(total: total, available: available)
    }

    // iOS only permits an app to remove files inside its own sandbox.
    static func cacheBytes() -> Int64 {
        let fm = FileManager.default
        let urls = [
            fm.urls(for: .cachesDirectory, in: .userDomainMask).first,
            fm.temporaryDirectory
        ].compactMap { $0 }
        return urls.reduce(0) { $0 + directorySize(at: $1) }
    }

    static func cleanOwnCache() throws -> Int64 {
        let fm = FileManager.default
        let urls = [
            fm.urls(for: .cachesDirectory, in: .userDomainMask).first,
            fm.temporaryDirectory
        ].compactMap { $0 }
        let before = urls.reduce(0) { $0 + directorySize(at: $1) }
        for folder in urls {
            let contents = try fm.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil)
            for item in contents {
                try fm.removeItem(at: item)
            }
        }
        return before
    }

    private static func directorySize(at url: URL) -> Int64 {
        let fm = FileManager.default
        guard let enumerator = fm.enumerator(
            at: url,
            includingPropertiesForKeys: [.isRegularFileKey, .fileSizeKey],
            options: [.skipsHiddenFiles]
        ) else { return 0 }
        var total: Int64 = 0
        for case let fileURL as URL in enumerator {
            let values = try? fileURL.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
            if values?.isRegularFile == true {
                total += Int64(values?.fileSize ?? 0)
            }
        }
        return total
    }
}
